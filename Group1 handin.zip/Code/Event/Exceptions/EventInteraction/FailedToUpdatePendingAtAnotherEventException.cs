﻿using System;

namespace Event.Exceptions.EventInteraction
{
    public class FailedToUpdatePendingAtAnotherEventException : Exception
    {
    }
}