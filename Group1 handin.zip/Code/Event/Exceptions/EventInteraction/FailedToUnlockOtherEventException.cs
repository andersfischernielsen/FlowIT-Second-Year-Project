using System;

namespace Event.Exceptions
{
    public class FailedToUnlockOtherEventException : Exception
    {
    }
}