using System;

namespace Event.Exceptions
{
    public class FailedToLockOtherEventException : Exception
    {
    }
}