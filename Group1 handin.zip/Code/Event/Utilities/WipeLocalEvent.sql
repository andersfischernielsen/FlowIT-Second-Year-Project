﻿DELETE FROM ConditionUris;
DELETE FROM EventModels;
DELETE FROM EventRoleModels;
DELETE FROM ExclusionUris;
DELETE FROM HistoryModels;
DELETE FROM InclusionUris;
DELETE FROM ResponseUris;

DELETE FROM ConditionUris;
DELETE FROM EventModels;
DELETE FROM EventRoleModels;
DELETE FROM ExclusionUris;
DELETE FROM HistoryModels;
DELETE FROM InclusionUris;
DELETE FROM ResponseUris;