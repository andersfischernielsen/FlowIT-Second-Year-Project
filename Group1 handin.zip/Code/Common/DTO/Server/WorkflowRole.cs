﻿namespace Common.DTO.Server
{
    public class WorkflowRole
    {
        public string Role { get; set; }
        public string Workflow { get; set; }
    }
}