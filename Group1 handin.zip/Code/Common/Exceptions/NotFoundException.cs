using System;

namespace Common.Exceptions
{
    public class NotFoundException : Exception
    {
    }
}