﻿using System;

namespace Common.Exceptions
{
    public class EventExistsException : Exception
    {
    }
}