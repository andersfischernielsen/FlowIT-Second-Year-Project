﻿namespace Client.ViewModels
{
    public interface IWorkflowListViewModel
    {
        string Status { get; set; }
    }
}
