# README

To run the program and execute events in workflows, open "Client.exe", located in the "CompiledClient" folder.

To parse your own exported DCRGraphs.net .xml files, open "XMLtoJSONParser.exe" in the "CompiledParser" folder. 

The user you choose to login can only see workflows that the user has a role in.  

The system has several workflows in it on launch. 



## Initial Healtcare Workflow

The workflow has several roles with (case sensistive) password: 

Password

### Admin

### CheckInReceptionist

### QueueReceptionist

### Examiner

### Specialist



## Final Healthcare Workflow

The workflow has the same roles as the Initial workflow with the added role of:

### Nurse



## Mortgage Application Workflow

The workflow has several roles with (case sensistive) password: 

Password

### Admin

### Auditor

### Customer

### Intern

### Caseworker

### Mobile Consultant

### IT System



## Gas Consumption Workflow

The workflow has several roles with (case sensistive) passwords:


### Admin

### Customer

### Inspector
